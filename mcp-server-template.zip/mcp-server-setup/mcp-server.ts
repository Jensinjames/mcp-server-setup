// Entry point for the MCP server
console.log('MCP Server started');
