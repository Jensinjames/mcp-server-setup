// Version control for model contexts
