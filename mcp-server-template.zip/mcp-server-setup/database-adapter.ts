// Abstract DB adapter interface
