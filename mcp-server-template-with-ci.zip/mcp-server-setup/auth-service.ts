// Logic for authentication services
