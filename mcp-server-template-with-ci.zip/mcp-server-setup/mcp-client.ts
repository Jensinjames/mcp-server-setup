// Client-specific interactions
