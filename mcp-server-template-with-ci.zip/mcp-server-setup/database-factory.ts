// Factory to instantiate DB connections
