// Logic to augment base model context
