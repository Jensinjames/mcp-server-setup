// Middleware to handle authentication
