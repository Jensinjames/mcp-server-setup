// In-memory DB adapter for testing
