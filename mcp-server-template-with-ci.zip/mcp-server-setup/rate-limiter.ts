// Basic rate-limiting logic
