
import express from "express";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse";
import { registerEchoTool } from "./tools/echoTool";
import jwt from "jsonwebtoken";
import fs from "fs";
import path from "path";

const app = express();
app.use(express.json());

const server = new McpServer({ name: "admin-server", version: "1.0.0" });
registerEchoTool(server);

const transports = {};

const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).send("Token missing");
  try {
    req.user = jwt.verify(token, "secret");
    next();
  } catch {
    res.status(401).send("Invalid token");
  }
};

app.get("/sse", authenticate, async (req, res) => {
  const transport = new SSEServerTransport("/messages", res);
  transports[transport.sessionId] = transport;
  res.on("close", () => delete transports[transport.sessionId]);
  await server.connect(transport);
});

app.post("/messages", authenticate, async (req, res) => {
  const sessionId = req.query.sessionId;
  const transport = transports[sessionId];
  if (!transport) return res.status(400).send("Invalid sessionId");
  const logPath = path.join("logs", `${sessionId}.log`);
  fs.appendFileSync(logPath, JSON.stringify(req.body) + "\n");
  await transport.handlePostMessage(req, res);
});

app.post("/tools", authenticate, (req, res) => {
  const { name, inputSchema, logic } = req.body;
  const fn = new Function("args", `return (${logic})(args)`);
  server.tool(name, eval(inputSchema), fn);
  res.send({ status: "Tool registered" });
});

app.listen(3000, () => console.log("🚀 MCP Admin Server running on port 3000"));
